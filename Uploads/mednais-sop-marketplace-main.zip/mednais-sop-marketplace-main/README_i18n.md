# 🌍 Руководство по мультиязычности

Приложение использует простую и эффективную систему мультиязычности на основе React Context API.

## 📁 Структура

```
lib/i18n/
├── locales.ts           # Список языков и их названия
├── translations.ts      # Файл со всеми переводами
└── LanguageContext.tsx  # React Context провайдер
```

## 🎯 Поддерживаемые языки

- 🇬🇧 English (en)
- 🇪🇸 Español (es)
- 🇫🇷 Français (fr)
- 🇩🇪 Deutsch (de)
- 🇨🇳 中文 (zh)
- 🇸🇦 العربية (ar)
- 🇵🇹 Português (pt)
- 🇵🇱 Polski (pl)
- 🇷🇺 Русский (ru)
- 🇺🇦 Українська (uk)

## 📝 Как добавить новые переводы

### 1. Добавьте ключи в `/lib/i18n/translations.ts`

```typescript
export const translations = {
  en: {
    common: {
      signIn: 'Sign In',
      signUp: 'Sign Up',
      // Добавьте новые ключи здесь
      myNewKey: 'My New Text',
    },
    // Добавьте новые секции
    mySection: {
      title: 'My Title',
      description: 'My Description',
    },
  },
  ru: {
    common: {
      signIn: 'Войти',
      signUp: 'Регистрация',
      // Добавьте переводы на русский
      myNewKey: 'Мой новый текст',
    },
    mySection: {
      title: 'Мой заголовок',
      description: 'Моё описание',
    },
  },
  // Повторите для всех языков
};
```

### 2. Используйте переводы в компонентах

```typescript
'use client';

import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function MyComponent() {
  const { t } = useLanguage();

  return (
    <div>
      <h1>{t('mySection', 'title')}</h1>
      <p>{t('mySection', 'description')}</p>
      <button>{t('common', 'myNewKey')}</button>
    </div>
  );
}
```

## 🔄 Переключатель языков

Компонент `<LanguageSwitcher />` уже интегрирован в навигацию. Он автоматически:
- Показывает все доступные языки
- Сохраняет выбор в localStorage
- Обновляет атрибут lang в HTML

## ⚙️ Как это работает

1. **LanguageContext** - предоставляет текущий язык и функцию перевода
2. **localStorage** - сохраняет выбранный язык между сессиями
3. **t(section, key)** - функция для получения перевода

## 🚀 Добавление нового языка

1. Добавьте код языка в `/lib/i18n/locales.ts`:
```typescript
export const locales = ['en', 'es', 'fr', 'de', 'zh', 'ar', 'pt', 'pl', 'ru', 'uk', 'ja'] as const;

export const localeNames: Record<Locale, string> = {
  // ... existing
  ja: '日本語',
};
```

2. Добавьте переводы в `/lib/i18n/translations.ts`:
```typescript
export const translations = {
  // ... existing languages
  ja: {
    common: {
      signIn: 'サインイン',
      signUp: 'サインアップ',
      // ...
    },
  },
};
```

## 💡 Советы

- Используйте понятные ключи: `home.heroTitle` вместо `h1`
- Группируйте переводы по секциям (common, home, dashboard и т.д.)
- Всегда добавляйте переводы для ВСЕХ языков
- Для длинных текстов используйте описательные ключи

## 🎨 Текущее состояние

✅ Главная страница частично переведена (заголовки, кнопки)
⚠️ Остальные страницы пока на английском

Чтобы завершить перевод всех страниц:
1. Добавьте все необходимые ключи в translations.ts
2. Замените хардкод на вызовы t()
3. Протестируйте на всех языках
