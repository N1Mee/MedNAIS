export default function Test2Page() {
  return <div>Test2 Works!</div>;
}
