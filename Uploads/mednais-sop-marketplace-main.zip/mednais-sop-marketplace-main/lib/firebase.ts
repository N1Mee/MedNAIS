// Firebase is not needed for this demo app
// Authentication is handled through test endpoints
export const auth = null;
export const googleProvider = null;
export const appleProvider = null;
export default null;
