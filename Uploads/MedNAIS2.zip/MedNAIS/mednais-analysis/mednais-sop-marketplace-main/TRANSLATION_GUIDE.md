# 🌍 Полное руководство по мультиязычности приложения

## ✅ Что уже сделано

### 1. Базовая инфраструктура
- ✅ React Context API для управления языком
- ✅ 10 поддерживаемых языков (en, es, fr, de, zh, ar, pt, pl, ru, uk)
- ✅ Переключатель языков с иконкой глобуса
- ✅ Сохранение выбора в localStorage

### 2. Полностью переведённые компоненты
- ✅ **Navigation** - навигационное меню
- ✅ **Homepage** - главная страница
- ✅ **Common buttons** - общие кнопки (Sign In, Sign Up, Get Started, etc.)

### 3. Подготовлены переводы для
- ✅ Dashboard - панель управления
- ✅ Marketplace - маркетплейс
- ✅ Create SOP - создание СОП
- ✅ Auth pages - страницы авторизации

## 📁 Структура файлов

```
lib/i18n/
├── locales.ts                  # Список языков
├── translations.ts             # ВСЕ переводы (520+ строк)
└── LanguageContext.tsx         # React Context

components/
├── navigation.tsx              # ✅ ПЕРЕВЕДЕНО
├── language-switcher.tsx       # ✅ Переключатель языков
└── ...

app/app/
├── page.tsx                    # ✅ Главная страница (частично)
├── dashboard/page.tsx          # ⚠️  НУЖНО ОБНОВИТЬ
├── marketplace/page.tsx        # ⚠️  НУЖНО ОБНОВИТЬ
├── sops/create/page.tsx        # ⚠️  НУЖНО ОБНОВИТЬ
└── ...
```

## 🎯 Пошаговая инструкция: как завершить перевод

### Шаг 1: Добавить `useLanguage` в компонент

```typescript
'use client';

import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function MyPage() {
  const { t } = useLanguage();
  
  // Теперь используйте t('section', 'key')
}
```

### Шаг 2: Найти все хардкод строки

Найдите все текстовые строки в компоненте:
```tsx
<h1>Dashboard</h1>  // ❌ Хардкод
<Button>Create SOP</Button>  // ❌ Хардкод
```

### Шаг 3: Заменить на ключи переводов

```tsx
<h1>{t('nav', 'dashboard')}</h1>  // ✅ Использует перевод
<Button>{t('nav', 'createSOP')}</Button>  // ✅ Использует перевод
```

### Шаг 4: Добавить отсутствующие ключи в translations.ts

Если ключа нет, добавьте его для ВСЕХ языков:

```typescript
// В /lib/i18n/translations.ts

export const translations = {
  en: {
    mySection: {
      myNewKey: 'My English Text',
    },
  },
  ru: {
    mySection: {
      myNewKey: 'Мой русский текст',
    },
  },
  es: {
    mySection: {
      myNewKey: 'Mi texto en español',
    },
  },
  // ... и для всех остальных языков
};
```

## 📝 Примеры перевода страниц

### Пример 1: Dashboard Page

**До:**
```typescript
<PageHeader 
  title={`Welcome back, ${session.user.name}!`}
  description="Here's what's happening with your SOPs"
/>
```

**После:**
```typescript
const { t } = useLanguage();

<PageHeader 
  title={`${t('dashboard', 'welcome')}, ${session.user.name}!`}
  description={t('dashboard', 'subtitle')}
/>
```

### Пример 2: Marketplace Page

**До:**
```tsx
<PageHeader 
  title="MedNAIS SOPs"
  description="Discover and purchase expert-created Standard Operating Procedures"
/>
<Input placeholder="Search SOPs..." />
<Button>Refresh</Button>
```

**После:**
```tsx
const { t } = useLanguage();

<PageHeader 
  title={t('marketplace', 'title')}
  description={t('marketplace', 'subtitle')}
/>
<Input placeholder={t('marketplace', 'search')} />
<Button>{t('common', 'refresh')}</Button>
```

### Пример 3: Create SOP Page

**До:**
```tsx
<CardTitle>Basic Information</CardTitle>
<Label htmlFor="title">Title *</Label>
<Input placeholder="Enter SOP title" />
<Label htmlFor="description">Description *</Label>
<Textarea placeholder="Describe what this SOP covers" />
```

**После:**
```tsx
const { t } = useLanguage();

<CardTitle>{t('sops.create', 'basicInfo')}</CardTitle>
<Label htmlFor="title">{t('sops.create', 'title')} *</Label>
<Input placeholder={t('sops.create', 'titlePlaceholder')} />
<Label htmlFor="description">{t('sops.create', 'description')} *</Label>
<Textarea placeholder={t('sops.create', 'descPlaceholder')} />
```

## 🚀 Быстрый старт: перевод новой страницы

1. **Открыть страницу** (например, `/app/app/dashboard/page.tsx`)

2. **Добавить хук useLanguage:**
   ```typescript
   const { t } = useLanguage();
   ```

3. **Найти все строки для перевода** и заменить:
   ```bash
   # Поиск всех строк в кавычках
   grep -n '"[A-Z]' dashboard/page.tsx
   ```

4. **Создать ключи в translations.ts** для каждой строки

5. **Протестировать** переключение языков

## 🔄 Автоматизация (опционально)

Создайте скрипт для автоматического извлечения строк:

```bash
# Найти все потенциальные строки для перевода
grep -rn --include="*.tsx" --include="*.ts" -E ">[A-Z][a-z]+|placeholder=\"[A-Z]|title=\"[A-Z]" app/app/
```

## 💡 Советы и best practices

### 1. Структура ключей
```typescript
// ✅ Хорошо - понятная иерархия
t('dashboard.stats', 'created')
t('marketplace.filters', 'category')
t('sops.create', 'stepTitle')

// ❌ Плохо - плоская структура
t('dashboardCreated')
t('marketplaceCategory')
```

### 2. Группировка по страницам/компонентам
```typescript
translations = {
  common: {},      // Общие элементы (кнопки, слова)
  nav: {},         // Навигация
  dashboard: {},   // Страница Dashboard
  marketplace: {}, // Страница Marketplace
  sops: {
    create: {},    // Подраздел: Create SOP
    edit: {},      // Подраздел: Edit SOP
  }
}
```

### 3. Переменные в переводах
```typescript
// Для динамических значений используйте string interpolation
`${t('dashboard', 'welcome')}, ${userName}!`

// ИЛИ храните шаблон
welcome: 'Welcome back' 
// И добавляйте имя в коде
```

### 4. Pluralization (множественное число)
```typescript
// Простой способ
${count} ${count === 1 ? t('common', 'sop') : t('common', 'sops')}

// ИЛИ создайте отдельные ключи
sopSingular: 'SOP'
sopPlural: 'SOPs'
```

## 📊 Прогресс перевода

### ✅ Полностью готово (100%)
- [x] Navigation (навигация)
- [x] Language Switcher
- [x] Homepage hero section

### ⚠️  Частично готово (переводы есть, нужно интегрировать)
- [ ] Dashboard (~50% - переводы готовы, нужно добавить t() вызовы)
- [ ] Marketplace (~50% - переводы готовы, нужно добавить t() вызовы)
- [ ] Create SOP (~70% - переводы готовы, нужно добавить t() вызовы)
- [ ] Auth pages (~80% - переводы готовы, нужно добавить t() вызовы)

### 🔲 Не начато (0%)
- [ ] SOPs list page
- [ ] SOP detail page
- [ ] SOP execute page
- [ ] Groups pages
- [ ] Sessions pages
- [ ] Profile pages

## 🎨 Тестирование переводов

### Ручное тестирование
1. Откройте приложение
2. Кликните на иконку глобуса
3. Выберите язык (например, Русский)
4. Проверьте, что все тексты изменились
5. Повторите для каждой страницы

### Автоматизированная проверка
```typescript
// Проверьте, что все ключи присутствуют во всех языках
Object.keys(translations.en).forEach(section => {
  Object.keys(translations.en[section]).forEach(key => {
    Object.keys(translations).forEach(lang => {
      if (!translations[lang][section]?.[key]) {
        console.warn(`Missing: ${lang}.${section}.${key}`);
      }
    });
  });
});
```

## 🌐 Добавление нового языка

### 1. Обновить locales.ts
```typescript
export const locales = ['en', 'es', ..., 'ja'] as const;

export const localeNames: Record<Locale, string> = {
  // ...
  ja: '日本語',
};
```

### 2. Добавить переводы в translations.ts
```typescript
export const translations = {
  // ... existing languages
  ja: {
    common: {
      signIn: 'サインイン',
      // ... all other keys
    },
    // ... all other sections
  },
};
```

## 📚 Ресурсы для переводов

### Автоматические переводы (для черновиков)
- Google Translate API
- DeepL API
- ChatGPT для контекстуальных переводов

### Профессиональные переводы
- Для production рекомендуется профессиональный перевод
- Особенно важно для языков с RTL (ar - арабский)
- Проверка носителями языка

## 🔧 Инструменты разработки

### VS Code Extensions
- **i18n Ally** - визуализация и редактирование переводов
- **Better Comments** - выделение TODO для переводов

### Команды для разработки
```bash
# Найти страницы без переводов
grep -rn "const { t }" app/app/ | wc -l

# Найти хардкод строки
grep -rn --include="*.tsx" "\"[A-Z][a-zA-Z ]+\"" app/app/

# Проверить использование переводов
grep -rn "t('.*', '.*')" app/app/
```

## 🎯 Следующие шаги

1. **Начните с Dashboard** - это наиболее используемая страница
2. **Затем Marketplace** - вторая по важности
3. **Create SOP** - важно для создания контента
4. **Остальные страницы** - по приоритету использования

## 📞 Поддержка

Если возникли вопросы:
1. Проверьте `/README_i18n.md` - базовое руководство
2. Посмотрите примеры в `navigation.tsx` и `page.tsx`
3. Проверьте структуру в `/lib/i18n/translations.ts`

---

**Примечание:** Все переводы в `/lib/i18n/translations.ts` уже подготовлены для основных секций. Вам нужно только добавить вызовы `t()` в компоненты!
