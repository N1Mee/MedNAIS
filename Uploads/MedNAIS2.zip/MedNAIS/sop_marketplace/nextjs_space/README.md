
# 📋 SOP Marketplace - Standard Operating Procedures Platform

Современная платформа для создания, продажи и выполнения стандартных операционных процедур (SOPs) с интеграцией AI и Stripe.

## 🚀 Основные возможности

### Для покупателей (Buyers)
- 🛒 **Корзина покупок** - добавляйте несколько SOPs и оплачивайте одним платежом
- 🔍 **Поиск и фильтрация** - находите нужные SOPs по категориям
- ⭐ **Рейтинги и отзывы** - читайте отзывы других пользователей
- 📊 **Dashboard** - отслеживайте свои покупки и прогресс
- 🎯 **Выполнение SOPs** - пошаговое выполнение с таймерами и вопросами

### Для продавцов (Sellers)
- ✍️ **Создание SOPs** - визуальный редактор с drag-and-drop
- 🤖 **AI генерация** - создавайте SOPs из документов с помощью ChatGPT
- 💰 **Монетизация** - получайте 70% от продаж
- 📈 **Аналитика** - следите за продажами и популярностью
- 🖼️ **Медиа поддержка** - добавляйте изображения и YouTube видео

### Технологические особенности
- 💳 **Stripe интеграция** - безопасные платежи
- 🌐 **Мультиязычность** - поддержка разных языков
- 🎨 **Темная/светлая тема** - адаптивный дизайн
- 📱 **Responsive** - работает на всех устройствах
- ☁️ **AWS S3** - хранилище файлов

## 🏗️ Технический стек

- **Frontend**: Next.js 14.2.28 (App Router), TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: PostgreSQL
- **Authentication**: NextAuth (Magic Links)
- **Payment**: Stripe
- **Storage**: AWS S3
- **AI**: Abacus.AI API (ChatGPT 5.1)
- **UI Components**: Radix UI, Lucide Icons

## 📦 Установка и запуск

### Предварительные требования
- Node.js 18+
- Yarn
- PostgreSQL
- AWS аккаунт (для S3)
- Stripe аккаунт

### Переменные окружения (.env)
```env
DATABASE_URL="postgresql://..."
NEXTAUTH_SECRET="..."
NEXTAUTH_URL="http://localhost:3000"

# Stripe
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_PUBLISHABLE_KEY="pk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_..."

# AWS S3
AWS_BUCKET_NAME="..."
AWS_FOLDER_PREFIX="..."

# Abacus.AI
ABACUSAI_API_KEY="..."

# Email (для magic links)
EMAIL_SERVER="smtp://..."
EMAIL_FROM="noreply@example.com"
```

### Команды

```bash
# Установка зависимостей
yarn install

# Генерация Prisma клиента
yarn prisma generate

# Миграция базы данных
yarn prisma db push

# Заполнение базы тестовыми данными
yarn prisma db seed

# Запуск dev сервера
yarn dev

# Сборка для production
yarn build

# Запуск production сервера
yarn start
```

## 📚 Структура проекта

```
nextjs_space/
├── app/                      # Next.js App Router
│   ├── api/                  # API routes
│   │   ├── auth/            # Аутентификация
│   │   ├── cart/            # Корзина
│   │   ├── checkout/        # Оплата
│   │   ├── sops/            # SOPs
│   │   ├── sessions/        # Выполнение
│   │   ├── ratings/         # Рейтинги
│   │   └── comments/        # Комментарии
│   ├── marketplace/         # Маркетплейс
│   ├── cart/                # Корзина покупок
│   ├── dashboard/           # Дашборд
│   ├── sops/                # SOPs страницы
│   └── profile/             # Профили
├── components/              # React компоненты
├── lib/                     # Утилиты и конфигурация
├── prisma/                  # База данных
└── public/                  # Статические файлы
```

## 🔐 Аутентификация

Приложение использует NextAuth с двумя методами:

1. **Magic Links** (production)
   - Пользователи получают ссылку на email
   - Без паролей, безопасно

2. **Credentials** (testing)
   - Автологин для `m@ivdgroup.eu`
   - Отключите перед production!

## 💰 Платежи и комиссии

- Платформа: **30%** от каждой продажи
- Продавец: **70%** от каждой продажи
- Обработка: Stripe (дополнительная комиссия ~3%)

## 📱 Основные страницы

| Страница | URL | Описание |
|----------|-----|----------|
| Главная | `/` | Landing page |
| Маркетплейс | `/marketplace` | Каталог SOPs |
| Корзина | `/cart` | Корзина покупок |
| Dashboard | `/dashboard` | Личный кабинет |
| Создание SOP | `/sops/new` | Редактор SOPs |
| Выполнение | `/sops/[id]/run` | Исполнение SOP |
| Профиль | `/profile/[id]` | Профиль пользователя |

## 🔧 Настройка Stripe

1. Создайте аккаунт на [stripe.com](https://stripe.com)
2. Получите API ключи в Dashboard
3. Настройте webhook на `/api/webhooks/stripe`
4. Добавьте события:
   - `checkout.session.completed`
   - `payment_intent.payment_failed`

## ☁️ Настройка AWS S3

1. Создайте S3 bucket
2. Настройте IAM пользователя с правами на:
   - `s3:PutObject`
   - `s3:GetObject`
   - `s3:DeleteObject`
3. Установите переменные AWS_BUCKET_NAME

## 🤖 AI генерация SOPs

Приложение использует Abacus.AI API для:
- Извлечения текста из PDF документов
- Генерации структурированных SOPs
- Поддержки мультиязычности

## 📊 База данных

Схема включает:
- **Users** - пользователи (buyers/sellers)
- **SOPs** - операционные процедуры
- **Steps** - шаги процедур
- **CartItems** - товары в корзине
- **Purchases** - покупки
- **Sessions** - выполнение SOPs
- **Ratings** - рейтинги
- **Comments** - комментарии

## 🐛 Решение проблем

### Ошибка Prisma
```bash
yarn prisma generate
yarn prisma db push
```

### Ошибка NextAuth
- Проверьте NEXTAUTH_SECRET
- Убедитесь, что NEXTAUTH_URL правильный

### Ошибка Stripe
- Проверьте webhook secret
- Используйте Stripe CLI для локального тестирования

## 📝 TODO перед production

- [ ] Отключить автологин в `/app/auth/signin/page.tsx`
- [ ] Настроить SMTP сервер для magic links
- [ ] Настроить домен в NEXTAUTH_URL
- [ ] Включить rate limiting
- [ ] Настроить monitoring
- [ ] Добавить analytics

## 👥 Тестовые аккаунты

- **Seller**: `m@ivdgroup.eu` (автологин)
- **Seller**: `john@doe.com` (magic link)

## 📄 Лицензия

Proprietary - все права защищены

## 🤝 Поддержка

Для вопросов и поддержки: support@example.com

---

Сделано с ❤️ на Next.js и TypeScript
